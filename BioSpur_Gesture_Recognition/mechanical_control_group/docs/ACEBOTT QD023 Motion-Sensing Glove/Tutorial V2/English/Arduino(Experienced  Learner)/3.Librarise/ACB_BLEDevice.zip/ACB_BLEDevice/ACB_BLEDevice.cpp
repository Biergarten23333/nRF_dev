#include "ACB_BLEDevice.h"
#include <regex>

// Declare a pointer to hold the characteristic
BLECharacteristic *ACB_BLEDevice::pCharacteristic = NULL;
bool ACB_BLEDevice::deviceConnected = false; // Flag to track whether a client is connected

std::string ACB_BLEDevice::last = "True";
String ACB_BLEDevice::SERVICE_UUID = "";
String ACB_BLEDevice::CHARACTERISTIC_UUID = "";

// Server callback class to handle client connections and disconnections
class MyServerCallbacks : public BLEServerCallbacks
{
    void onConnect(BLEServer *pServer)
    {
        ACB_BLEDevice::deviceConnected = true; // Set the flag to true when a device connects
    }

    void onDisconnect(BLEServer *pServer)
    {
        ACB_BLEDevice::deviceConnected = false;     // Set the flag to false when a device disconnects
        pServer->startAdvertising(); // Restart advertising to allow new connections
    }
};

class MyCharacteristicCallbacks : public BLECharacteristicCallbacks
{
    void onWrite(BLECharacteristic *pCharacteristic)
    {
        std::string value = ACB_BLEDevice::pCharacteristic->getValue();

        if (value.length() > 0)
        {
            ACB_BLEDevice::last = value;
        }
    }
};


ACB_BLEDevice::ACB_BLEDevice(String service_uuid,String charact_uuid)
{
  ACB_BLEDevice::SERVICE_UUID = service_uuid.c_str();
  ACB_BLEDevice::CHARACTERISTIC_UUID = charact_uuid.c_str();
    // Serial.begin(115200);
    // Serial.println(ACB_BLEDevice::last.c_str());
}

void ACB_BLEDevice::Bluetooth_Name(String blu_name)
{
    std::string deviceName = blu_name.c_str();
    BLEDevice::init(deviceName); // Initialize the BLE device with a name

    // Create a BLE Server and service
    BLEServer *pServer = BLEDevice::createServer();              // Create a server instance
    BLEService *pService = pServer->createService(ACB_BLEDevice::SERVICE_UUID.c_str()); // Create a service with the defined UUID

    // Create a characteristic with read, write, notify, and indicate properties
    ACB_BLEDevice::pCharacteristic = pService->createCharacteristic(
        ACB_BLEDevice::CHARACTERISTIC_UUID.c_str(),
        BLECharacteristic::PROPERTY_READ |       // Allow reading the characteristic
            BLECharacteristic::PROPERTY_WRITE |  // Allow writing to the characteristic
            BLECharacteristic::PROPERTY_NOTIFY | // Enable notifications
            BLECharacteristic::PROPERTY_INDICATE // Enable indications
    );

    // Set the initial value of the characteristic
    // pCharacteristic->setValue("Hello World!"); // Initial characteristic value
    ACB_BLEDevice::pCharacteristic->addDescriptor(new BLE2902()); // Add descriptor for notifications (mandatory for notify/indicate)

    // Assign the callback methods to handle connections
    pServer->setCallbacks(new MyServerCallbacks()); // Bind the server callback functions
    pService->start();                              // Start the service

    // Setup advertising for the BLE service
    BLEAdvertising *pAdvertising = BLEDevice::getAdvertising(); // Create an advertising instance
    pAdvertising->addServiceUUID(ACB_BLEDevice::SERVICE_UUID.c_str());                 // Add the service UUID to the advertising
    BLEDevice::startAdvertising();                              // Start broadcasting the service

    // pCharacteristic->setCallbacks(new MyCharacteristicCallbacks());
}

void ACB_BLEDevice::ServerSend(String key)
{
    String temp = key;
    ACB_BLEDevice::pCharacteristic->setValue(temp.c_str()); // Update the characteristic value
    ACB_BLEDevice::pCharacteristic->notify();
};

void ACB_BLEDevice::ServerReceived()
{
    std::string value = ACB_BLEDevice::pCharacteristic->getValue();
    // Serial.println("------------");
    // Serial.println(value.c_str());
    // Serial.println("------------");
    ServerData = String(value.c_str());
}

// ----------------------- receive ble -----------------------
// Flags for scanning, connecting, and connection status
boolean doScan = true;     // Indicates if the client should be scanning for devices
boolean doConnect = false; // Indicates the client should connect to the discovered device
boolean ACB_BLEDevice::connected = false; // Indicates if the client is currently connected to a server

BLEAdvertisedDevice *pServer = nullptr;                   // Pointer to hold the advertised device
BLERemoteCharacteristic *ACB_BLEDevice::pRemoteCharacteristic = nullptr; // Pointer for the remote characteristic
BLEClient *pClient = nullptr;                             // Pointer for the BLE client

String ACB_BLEDevice::blu_connect_name="";
String ACB_BLEDevice::ClientData="";

// Callback class to handle BLE device advertisement results
class MyAdvertisedDeviceCallbacks : public BLEAdvertisedDeviceCallbacks
{
public:
    void onResult(BLEAdvertisedDevice advertisedDevice)
    {
        // Check if the discovered device has the expected name
        if (advertisedDevice.haveName() && ACB_BLEDevice::blu_connect_name.equals(advertisedDevice.getName().c_str()))
        {
            advertisedDevice.getScan()->stop();                  // Stop the current scan
            pServer = new BLEAdvertisedDevice(advertisedDevice); // Store the discovered device
            doScan = false;                                      // Set flag to stop scanning
            doConnect = true;                                    // Set flag to initiate connection
        }
    }
};

// Callback class for managing BLE client connection status
class MyClientCallback : public BLEClientCallbacks
{
public:
    void onConnect(BLEClient *pclient)
    {
        ACB_BLEDevice::connected = true;                           // Set connected status to true when connected
        Serial.println("Connected to the server."); // Print message indicating successful connection
    }

    void onDisconnect(BLEClient *pclient)
    {
        ACB_BLEDevice::connected = false; // Set connected status to false when disconnected
        doScan = true;     // Set flag to allow new scans
        if (pClient)
        {
            delete pClient; // Free the client object
            pClient = nullptr;
        }
    }
};

// Callback function for receiving notifications from the server
void NotifyCallback(BLERemoteCharacteristic *pBLERemoteCharacteristic, uint8_t *pData, size_t length, bool isNotify)
{
    char buf[length + 1];        // Create a buffer to hold the incoming data
    memcpy(buf, pData, length);  // Copy data into the buffer
    buf[length] = '\0';          // Null-terminate the string
    // Serial.println("------------");
    // Serial.println(buf);
    // Serial.println("------------");
    ACB_BLEDevice::ClientData = buf;

    // Check if the received data matches " "
}

// Function to connect to the BLE server and obtain the service and characteristic
bool ConnectToServer() {

    pClient = BLEDevice::createClient();  // Create a new BLE client
    if (!pClient) {
      return false;  // Return false if client creation fails
    }

    pClient->setClientCallbacks(new MyClientCallback());  // Assigning callback for connection events

    if (!pClient->connect(pServer)) {  // Attempt to connect to the advertised device
      delete pClient;                  // Clean up if connection fails
      pClient = nullptr;
      return false;
    }

    // Obtain the desired service from the connected device
    BLERemoteService* pRemoteService = pClient->getService(ACB_BLEDevice::SERVICE_UUID.c_str());  // Get the service
    if (!pRemoteService) {
      pClient->disconnect();  // Disconnect if the service is not found
      return false;
    }

    // Obtain the characteristic from the service
    ACB_BLEDevice::pRemoteCharacteristic = pRemoteService->getCharacteristic(ACB_BLEDevice::CHARACTERISTIC_UUID.c_str());
    if (!ACB_BLEDevice::pRemoteCharacteristic) {
      pClient->disconnect();  // Disconnect if the characteristic is not found
      return false;
    }

    // Optional: Read the initial value of the characteristic
    if (ACB_BLEDevice::pRemoteCharacteristic->canRead()) {
      ACB_BLEDevice::pRemoteCharacteristic->readValue();  // Read the current value
    }

    // Register for notifications if supported
    if (ACB_BLEDevice::pRemoteCharacteristic->canNotify()) {
      ACB_BLEDevice::pRemoteCharacteristic->registerForNotify(NotifyCallback);  // Register the callback for notifications
    }

    return true;  // Return true if connection and service/characteristic retrieval is successful
}

void ACB_BLEDevice::Bluetooth_Connected(String blu_name)
{   
    ACB_BLEDevice::blu_connect_name = blu_name.c_str();
    BLEDevice::init("");   // Initialize the BLE device

    // Create a scanner to search for advertised devices
    BLEScan* pBLEScan = BLEDevice::getScan();
    pBLEScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks());  // Set the callback for device discovery
    pBLEScan->setActiveScan(true);                                              // Use active scan for more detailed responses
    pBLEScan->setInterval(100);                                                 // Set the scan interval
    pBLEScan->setWindow(80);                                                    // Set the scan window
}

void ACB_BLEDevice::ClientReceived()
{
    // If scanning is enabled, continuously scan for devices
    if (doScan) {
      BLEDevice::getScan()->clearResults();  // Clear previous scan results
      BLEDevice::getScan()->start(0);        // Start scanning indefinitely
    }

    // If a device has been discovered, attempt to connect to it
    if (doConnect) {
      if (ConnectToServer()) {  // Attempt to connect
        ACB_BLEDevice::connected = true;       // Update the connection status if successful
      } else {
        doScan = true;  // Restart scanning if connecting fails
      }
      doConnect = false;  // Reset the connection flag
    }

    // If connected and characteristic is writable, send data
    // if (ACB_BLEDevice::connected && ACB_BLEDevice::pRemoteCharacteristic && ACB_BLEDevice::pRemoteCharacteristic->canWrite()) {
    //   String newValue = "mytime: " + String(millis() / 1000);                  // Prepare a string message
    //   ACB_BLEDevice::pRemoteCharacteristic->writeValue(newValue.c_str(), newValue.length());  // Write the message to the characteristic
    //   delay(100);                                                             // Control the sending interval (3.5 seconds)
    // }
}

void ACB_BLEDevice::ClientSend(String key)
{
    if (doScan) {
      BLEDevice::getScan()->clearResults();  // Clear previous scan results
      BLEDevice::getScan()->start(0);        // Start scanning indefinitely
    }

    // If a device has been discovered, attempt to connect to it
    if (doConnect) {
      if (ConnectToServer()) {  // Attempt to connect
        ACB_BLEDevice::connected = true;       // Update the connection status if successful
      } else {
        doScan = true;  // Restart scanning if connecting fails
      }
      doConnect = false;  // Reset the connection flag
    }
    
    // If scanning is enabled, continuously scan for devices
    
    if (doScan && ACB_BLEDevice::connected) {
      BLEDevice::getScan()->clearResults();  // Clear previous scan results
      BLEDevice::getScan()->start(0);        // Start scanning indefinitely
    }

    // If a device has been discovered, attempt to connect to it
    if (doConnect) {
      if (ConnectToServer()) {  // Attempt to connect
        ACB_BLEDevice::connected = true;       // Update the connection status if successful
      } else {
        doScan = true;  // Restart scanning if connecting fails
      }
      doConnect = false;  // Reset the connection flag
    }

    if (ACB_BLEDevice::pRemoteCharacteristic) {
        String status = key;
        // Serial.println("***********");
        // Serial.println(status);
        // Serial.println("***********");
        ACB_BLEDevice::pRemoteCharacteristic->writeValue(status.c_str());
    } else {
        
    }
}

// ----------------------- receive ble -----------------------