#ifndef ACB_BLEDevice_H
#define ACB_BLEDevice_H

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLE2902.h>

class ACB_BLEDevice
{
	public:
		ACB_BLEDevice(String service_uuid,String charact_uuid);

        void Bluetooth_Name(String blu_name);
		void ServerSend(String key);
		void ServerReceived();


		void Bluetooth_Connected(String blu_name);
		void ClientReceived();
		void ClientSend(String key);

		static String SERVICE_UUID;
		static String CHARACTERISTIC_UUID;

		String ServerData="";
		static std::string last;
		static String blu_connect_name;
		static String ClientData;
		static bool deviceConnected; // Flag to track whether a client is connected
		static boolean connected; // Indicates if the client is currently connected to a server
		static BLECharacteristic *pCharacteristic;
		static BLERemoteCharacteristic *pRemoteCharacteristic;

	private:
        
};

#endif